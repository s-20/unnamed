# Characteristics

Characteristics are the things that, collected together, define a character in mechanical terms, and also provide a lot of clues into the character's life and what sort of person (or whatever) they are.

There are 7 primary Characteristics: [Aspects](Aspects.md), [Traits](Traits.md), [Skills](Skills.md), [Special Abilities](SpecialAbilities.md), [Connections](Connections.md), [Details](Details.md), and [Complications](Complications.md). In addition to these, there is also [Wound Threshold](WoundThreshold.md), and a few different types of [Energy](Energy.md).

## Aspects

## Traits

## Skills

## Special Abilities

## Connections

## Details

## Complications

## Wound Threshold

## Energy