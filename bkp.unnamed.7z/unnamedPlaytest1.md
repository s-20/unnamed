# unnamed Playtest1 Notes

## Zombies for Next Game

- Kaiser's Zombies? - Zombies in the past, before there was a bunch of technology.

## System Issues

- Wizard's Dilemma - options overwhelming esp. for newbs
- Descriptive rolls - take a look at that, linguistic gymnastics/repetitive
- Aspects need to be better defined (too broad - neuro aphla/daintree)

## Characters

### Hayley Santos

- spoiled pop star; manager murdered brutally (rivet through skull)

### Hashim Nash

- Restaruanteur
- Dead

### Sophia Hawk

- Station Doctor

### Jeramiah (AI Inventor)

- Alphabet

### Juniper (AI)

- Crazy Strong AI
- Trying to frame its creator for mass murder, but doesn't really understand motive

### Elspeth Mikaelson

- Administrator
- Dead