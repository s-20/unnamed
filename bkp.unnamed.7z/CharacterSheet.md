# Character Name

*Add a quote, a description, or whatever else you like here*

## [Origin](https://s-20.github.io/unnamed/#/Origin)

*About three sentences that describe who the character is and what they do.*

## [Aspects](https://s-20.github.io/unnamed/#/Aspects)

- One
- Two

## [Traits](https://s-20.github.io/unnamed/#/Traits)

- You
- Get
- Ten
- To
- Start

## [Talents and Skills](https://s-20.github.io/unnamed/#/Skills)

### Talents (select 2)

- One
- Two

### Skills (15 Skill Points)

- One
- Two
- Three
- Four
- Five
- Minimum

### Foci

- Free associated
- Focus with any Skill
- with a Stack of 5

## [Connections](https://s-20.github.io/unnamed/#/Connections)

- Spend 10 Connection Points
- To Buy At least
- 3 Connections

## [Special Abilities](https://s-20.github.io/unnamed/#/SpecialAbilities)

**Ability Name**
**Sketch**:
**Features**:
**Exploits**:
**Powers**:
**Procedures**:
**Side Effects**:
**Losses**:
**Flaws**:
**Details**:

### Energy

- Pool 1
- Pool 2

## [Details](https://s-20.github.io/unnamed/#/Details)

- You
- Get (up to)
- Five
- To
- Start

## [Complications](https://s-20.github.io/unnamed/#/Complications)

- You
- Get
- Up to three

## Stuff

Things you carry around with you or otherwise own; just list big important stuff or stuff you want to rely on for modifier dice, plus weapons and armor.

Stuff operates on a "Be Reasonable" system.

## [Advancements and Awards](https://s-20.github.io/unnamed/#/Advancement)

Track Advancements and Awards here, but don't forget to note it up above as well!

## Notes

A place for notes, background info, etc.