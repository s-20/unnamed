# Douglass Brackey 

## Origin

An international spy working undercover at Hilton for the Russian government.

## Aspects

- Massage Therapist
- International Spy

## Traits

- Perceptive
- Dexterous
- Creative
- Strong
- Likeable

## Skills

- Communication
  - Interrogation
  - Diplomacy
- Trade
  - Massage Therapist
- Thievery
  - Hacking
  - Surveillance
- Deception
  - Disguise

## Connections

- Val Swader
  - Meeting up on the voyage to purchase information for the Russian Govt.

## Details

- Perfect at accents