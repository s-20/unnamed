# Second Playtest: Victorian Zombies (Evil Crowley)

## Principle Players

- Pat - Gadgeteer - roll to gather "energy", spend to finish device
- Waffles - Fortune teller/Spiritist; skill checks for information from the Spirit World; coax spirits to help epyromancy 

### Protagonists

- Lord Edward Spice (Lord of the House, 48)
- Lady Elisabeth Spice (Lady of the Household, 42)
- Master George Spice (son, 18)
- The Spice Girls
  - Lady Elsa Spice (daughter, 12)
  - Lady Bertha Spice (daughter, 12)
  - Lady Carissa Spice (daughter, 12)
- The Spice Household
  - Butler (Wadsworth or Belvedere - sit on balls)
  - 4 Maids
  - Stabemaster
  - Stableboy
  - Coachman
  - Groundskeeper (William MacTavish)

Spice Manor is a day's ride from Cambridge

### Antagonists

 - Alestair Crowley, Necromancer (born 100 years ago rather than today)
 - Allen Kardek, Spiritist

October 12 1875. Lord Spice's Manor.

