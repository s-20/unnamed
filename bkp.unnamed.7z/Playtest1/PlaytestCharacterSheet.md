# Character Name

*Add a quote, a description, or whatever else you like here*

## [Origin](https://s-20.github.io/unnamed/#/Origin)

*About three sentences that describe who the character is and what they do.*

## [Aspects](https://s-20.github.io/unnamed/#/Aspects)

Five stacks in at least 2 Aspects

## [Traits](https://s-20.github.io/unnamed/#/Traits)

Ten stack in at least 3 different Traits

## [Talents](https://s-20.github.io/unnamed/#/Skills)

You get two!

## [Skills](https://s-20.github.io/unnamed/#/Skills)

15 SKill Points for at least 5 Skills, no more than 5 stack in any one skill at start. Skill stacks cost 1 point each.

Foci can be purchased at 2 Stack for 1 Skill point, no more than 4 in any one Focus to start

## [Connections](https://s-20.github.io/unnamed/#/Connections)

- At least 5
- More if it
- Makes sense

## [Special Abilities](https://s-20.github.io/unnamed/#/SpecialAbilities)

### (Name of SA)

- **Sketch**:
- **Exploits**:
  - *Energy*:
- **Powers**:
- More Stuff
- Copy and Paste for more SAs

## [Details](https://s-20.github.io/unnamed/#/Details)

- You
- Get up to
- Five

## [Complications](https://s-20.github.io/unnamed/#/Complications)

- You
- Get
- Up to three

## Stuff

Things you carry around with you or otherwise own; just list big important stuff or stuff you want to rely on for modifier dice, plus weapons and armor.

## [Advancements and Awards](https://s-20.github.io/unnamed/#/Advancement)

Track Advancements and Awards here, but don't forget to note it up above as well!

## Notes

A place for notes, background info, etc.
