# Knacks

Knacks are special abilities, powers, magic, or other distinctive abilities that make a character truly unique. Knacks are created individually, and tailored to specific characters, rather than selected from a list. Depending on the Knack in question, it may be built using a framework called a [Pattern](Patterns.md) for consistency or verisimilitude.

## Knack Basics

### Summary

### Breadth, Vigor, and Intensity

### Costs

## Patterns

### Pattern Example: Magic

### Pattern Example: Momentum