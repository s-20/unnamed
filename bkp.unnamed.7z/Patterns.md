# Patterns
