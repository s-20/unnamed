# Patterns
