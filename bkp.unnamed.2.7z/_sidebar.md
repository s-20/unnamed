<!-- system/_sidebar.md -->

# unnamed

[Github Project Page](https://github.com/s-20/unnamed)

## Vital Stuff

- [Core Mechanics](HBCore.md)
- [Character Creation](CCSummary.md)
- [To-Do](To-Do.md)

----

## Index

- [Advancement](Advancement.md)
- [Aspects](Aspects.md)
- [Burn](Burn.md)
- [Characteristics](Characteristic.md)
- [Combat](Combat.md)
- [Drama Dice](DramaDice.md)
- [Effort](Effort.md)
- [Skills](Skills.md)
  - [Foci](Foci.md)
- [Tangles](Tangles.md)
- [Traits](Traits.md)
  - [Meta-Traits](MetaTraits.md)
