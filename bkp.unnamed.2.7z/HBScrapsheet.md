# HB Game Scrap-sheet and Notes

Various stuff I need to save for later.
