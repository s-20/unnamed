# Quirks

Quirks are low dice results - usually 1s, but sometimes 2s as well. Quirks cause add things to happen if you get too many of them. This might mean higher difficulty going forward, or it might mean nothing at all. Roll enough Quirks, however, and you wind up with a Catastrophe, and that's no good for anyone.

## Quirking Up a Roll

## Catastrophe

## Quirks and Drama Dice
