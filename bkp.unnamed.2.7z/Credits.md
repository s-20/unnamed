# Credits

![Credits](_media/undraw_game_world_0o6q.png)


This page contains general thank-yous for those who support the game's development, and a place to provide credit for assets used in the game.

## Editors

I'd like to thank the following people for helping with copy editing, style checking, and otherwise helping my sometimes florid and obscure text become usable. I will add names as I get consent to print them

## Playtesters

Thank you all so much! T=I really appreciate the tie you've shared with me. It has made all the difference.

If you're playtesting the system, and you want to provide feedback, you can reach me at [enter feedback email here](mailto:unnamed.s20(at)whoknows.whatever). That link doesn't work yet.

## Art

There's not much art on this website, and all art present is either Public Domain or some other open license. That said, what little art there is was created by:

- [unDraw](https://undraw.co/license) - basically all the icons. I chose these because of their (incredibly) permissive license and clean look. They are, of course, placeholders.
