# To-Do

This is a running TODO list for the unnamed System. Feel free to send in any help you want.

## Updates Needed

These articles need to be updated to reflect recent changes. This includes articles that need to be completely overhauled to the point that they might need to be re-written completely (noted with an RW).

## Missing or Incomplete Articles

These articles are either missing or incomplete, and need to be added in. This includes ongoing articles that may ore may not need more additions going forward (noted with an ON)

- [Exploits.md](Exploits.md) - ON
  - Add in additional Exploits as you think of them - already have Aid and Recover
- [Quirks.md](Quirks.md)
  - Need to finish, plus need to update related references

## Other To-Do

Other stuff that needs doing, like missing graphics, places where tables or tabs would be helpful, or other such formatting fixes.

## Move to Book

If I ever get around to it, this is the stuff I need to get done to move everything to a PDF or other digital or Physical publication.

## Hopefully Done

These articles are (I hope) finished until playtest forces changes and can be safely ignored for further editing. Probably. Unless something chages.