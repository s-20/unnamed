<!-- _coverpage.md -->

![logo](_media/icon.png)

# an unnamed Flexible Roleplaying System <small>alpha 0.1</small>

> Under **heavy**, if sporadic, construction

- Medium-weight rules
- success-based d6 dice pools with fail-forward mechanics
- Streamlined GMing

[GitHub Page](https://github.com/s-20/unnamed)
[Core Rules](HBCore.md)
[Character Creation](CCSummary.md)