# unnamed? Really?

Yes, really. Well, actually, no.

The issue here is that I don't have a named for it. I keep thinking a name will naturally occur to me as I continue to develop the system, or someone will suggest a name and I'll snap my fingers and go *"YES!"*

But that hasn't happened yet.

So for right now, I'm just calling it unnamed. I'm not capitalizing unnamed because I legitimately hope I'll come up with something better. Or someone will. Whichever.

Either way, however, it's starting to remind me of the story of how GURPS got its name, and I don't know how I feel about that.

## Apocrypha: How GURPS got its name

I can't find a reference for it, so the story is probably apocryphal, but here goes. 

During Development of the full GURPS system, spinning off from [The Fantasy Trip](https://en.wikipedia.org/wiki/The_Fantasy_Trip), Steve Jackson used GURPS (which is an acronym meaning **G**eneric **U**niversal **R**ole **P**laying **S**ystem) as a working title, a kind of place-holder until he could come up with a better name.

Well, the deadline for submissions to the 1985 Origin Awards were rapidly approaching, so in order to get a submission in, he just ran with GURPS and the abridged version of the game he had at the time - [Man to Man: Fantasy Combat from GURPS](https://en.wikipedia.org/wiki/Steve_Jackson's_Man_to_Man). And then the working title just sort of stuck.

## My Point

If you've read this far, thanks for that! My point in this whole diatribe is that unnamed is a working title for the system. That's not its official name, however.

I'm not especially worried about an official name while the game is in this alpha state, but I will need a name eventually. If I wind up going with unnamed, I want it to be because it was the best name available, not because I got accustomed to it.

So, please, by all means, suggest names. I'm all ears.