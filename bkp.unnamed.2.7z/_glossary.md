# unnamed Glossary

Hopefully, this will be a useful page filled with definitions and links providing for quick reference throughout the wiki.

##### Characteristic

A specific part of the character that describes their abilities and hooks into game mechanics.

##### Skill 
##### Skills

Characteristics that represent things a character knows about, or knows how to do, or both. Skills are learned through practice or education. See [Skills](Skills.md)

##### Trait

##### Traits

Characteristics of a character that define broad areas of talent or training. Analogous to Attributes in other systems, Traits are pulled or Burned for checks, and can be stacked. See [Traits](Traits.md).
