<!-- system/_navbar.md -->

[<img src="https://i.creativecommons.org/l/by/4.0/88x31.png">](License.md)