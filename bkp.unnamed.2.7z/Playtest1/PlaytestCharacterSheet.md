# unnamed Character Sheet

*Add a quote, a description, or whatever else you like here*

## Conecpt

*About three sentences that describe who the character is and what they do.*

## [Aspects](https://s-20.github.io/unnamed/#/Aspects)

*Start with 2 different Aspects*

## [Traits](https://s-20.github.io/unnamed/#/Traits)

*Talents and general abilities*

## [Skills](https://s-20.github.io/unnamed/#/Skills) and [Foci](../Foci.md)

*Things you know how to do*

## [Connections](https://s-20.github.io/unnamed/#/Connections)

*Things that tie you to the world*

## [Details](https://s-20.github.io/unnamed/#/Details)

*Very little things that make you unique*

## [Knacks](https://s-20.github.io/unnamed/#/Knacks.md)

*Special, often supernatural, abilities*

## [Snags](https://s-20.github.io/unnamed/#/Snags.md)

*Things that make your life more difficult or interesting*

## Stuff

*The things you're carrying or otherwise have immediate access to*

### Assets

*Other stuff you have access to given time*

## Notes

A place for notes, background info, etc.

## Improvement

*Detail how many Improvements you've spent here, if you're into that sort of thing*