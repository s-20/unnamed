# Val Swader

## Current Events

Working for Hilton as transport/carrier pilot onboard brand new Saturn Based Resort Ship. Arrived 1 week ago prior to grand opening.  making a trade and deliver deal under this cover

## Aspects

- Outstanding pilot
- Renowned smuggler

## Origin

Val Swader is an Outstanding pilot & Renowned smuggler from the Mars Colonies. Joined the underground with big dreams of fortune and has, so far, achieved those dreams. Hoping to add one more success story to their bracket before retiring young and wealthy.

## Traits

- Perceptive
- Convincing
- Enduring
- Deceptive
- Lucky

## Skills

- Pilot
  - transports & carrier ships
- Ranged Combat
  - firearms
- Trade
  - smuggling
- Communication
  - diplomacy
- Technology
  - computers

## Connections

- Douglass Brackey (Jake)
    - *Meeting with one Douglass Brackey buying smuggled plans*
- Mercury (Pat)
    - *Previous undisclosed underground acquaintances*

## Details

## Complications

- Wanted Criminal
- Living? 

## Stuff

Handgun (22mm Ceramic Caseless Colt Hideaway m17)